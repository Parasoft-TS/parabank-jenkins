OWASP Dependency Check Pack documentation: https://docs.parasoft.com/display/DTP20242/OWASP+Dependency-Check+Pack

