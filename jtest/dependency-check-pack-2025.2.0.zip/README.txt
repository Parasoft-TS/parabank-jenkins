OWASP Dependency Check Pack documentation: https://docs.parasoft.com/display/DTP20252/OWASP+Dependency-Check+Pack

